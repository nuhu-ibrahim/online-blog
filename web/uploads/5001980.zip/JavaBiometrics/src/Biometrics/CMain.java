
public class CMain {

  public CMain() {
  }
  public static void main(String[] args) {
    CEntityForm classFormMain = new CEntityForm();
    //classFormMain.setSize(800,800);
    classFormMain.setVisible(true);

  }
}